exports.handler = async (event) => { return { statusCode: 200 }; };
